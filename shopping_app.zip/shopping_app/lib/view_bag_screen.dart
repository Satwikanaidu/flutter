import 'package:flutter/material.dart';
import 'home_screen.dart';  // Import Product model

class ViewBagScreen extends StatelessWidget {
  final List<Product> cart;

  ViewBagScreen({required this.cart});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Bag'),
      ),
      body: cart.isEmpty
          ? Center(child: Text('Your bag is empty'))
          : ListView.builder(
        itemCount: cart.length,
        itemBuilder: (context, index) {
          final product = cart[index];
          return ListTile(
            leading: Image.asset(product.image, height: 150, fit: BoxFit.cover),
            title: Text(product.name),
            subtitle: Text('\$${product.price}'),
          );
        },
      ),
    );
  }
}