import 'package:flutter/material.dart';
import 'view_bag_screen.dart';

// Product model class
class Product {
  final String name;
  final double price;
  final String image;

  Product({required this.name, required this.price, required this.image});
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Dummy list of products
  final List<Product> products = [
    Product(name: 'Product 1', price: 20.0, image: 'assets/images/product1.jpg'),
    Product(name: 'Product 2', price: 15.0, image: 'assets/images/product2.jpg'),
    Product(name: 'Product 3', price: 25.0, image: 'assets/images/product3.jpg'),
  ];

  // Dummy cart items
  final List<Product> cart = [];

  // Add product to the cart
  void _addToCart(Product product) {
    setState(() {
      cart.add(product);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${product.name} added to cart')),
    );
  }

  // View bag action
  void _viewBag() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ViewBagScreen(cart: cart),  // Passing cart to ViewBagScreen
      ),
    );
  }

  // Search action
  void _searchProducts() {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Search functionality')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home - Shop Now'),
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(product.image, height: 150, fit: BoxFit.cover),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    product.name,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text('\$${product.price}', style: TextStyle(fontSize: 16)),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    ElevatedButton(
                      onPressed: () => _addToCart(product),
                      child: Text('Add to Cart'),
                    ),
                    ElevatedButton(
                      onPressed: _viewBag,
                      child: Text('View Bag'),
                    ),
                    ElevatedButton(
                      onPressed: _searchProducts,
                      child: Text('Search'),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}